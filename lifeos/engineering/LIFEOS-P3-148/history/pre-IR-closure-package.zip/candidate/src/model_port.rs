//! Model capability owns no repository, authorization, source or tool access.
use crate::conversation_contract::*;
use crate::repository::Error;
use serde_json::{json, Value};
pub struct ModelResponse {
    pub text: String,
    pub usage: Option<Value>,
}
pub trait ModelPort {
    fn generate(&mut self, exact_body: &str, key: &[u8]) -> R<ModelResponse>;
}
pub struct SyntheticModel;
impl ModelPort for SyntheticModel {
    fn generate(&mut self, body: &str, _key: &[u8]) -> R<ModelResponse> {
        if crate::runtime_root::is_real() {
            return fail("real_capability_denied");
        }
        let b: Value = serde_json::from_str(body).map_err(|_| Error::new("provider_protocol"))?;
        let content = b["messages"][1]["content"]
            .as_str()
            .ok_or_else(|| Error::new("provider_protocol"))?;
        let quoted = content
            .split("[C1] source\n")
            .nth(1)
            .and_then(|s| s.split("\n\n").next())
            .ok_or_else(|| Error::new("provider_protocol"))?;
        Ok(ModelResponse{text:format!("合成离线演练：本次提交的来源片段为「{quoted}」[C1]。此回答用于验证发送、引用和反馈流程，不代表真实模型理解。"),usage:None})
    }
}
pub fn citations(text: &str, items: &[Value]) -> (Vec<Value>, usize) {
    let mut valid = Vec::new();
    let mut invalid = 0;
    for chunk in text.split('[').skip(1) {
        let Some(end) = chunk.find(']') else { continue };
        let id = &chunk[..end];
        if !id.starts_with('C') {
            continue;
        }
        if let Some(item) = items
            .iter()
            .find(|i| i["kind"] == "source" && i["citationId"] == id)
        {
            if !valid.iter().any(|c: &Value| c["citationId"] == id) {
                valid.push(
                    json!({"citationId":id,"source":item["source"],"availability":"available"}),
                );
            }
        } else {
            invalid += 1
        }
    }
    (valid, invalid)
}
