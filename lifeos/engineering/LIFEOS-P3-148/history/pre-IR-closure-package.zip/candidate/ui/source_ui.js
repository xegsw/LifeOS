import { SourceConversation } from './source_conversation.js';
const real = window.__LIFEOS_REAL_SOURCE__ === true;
const sendLabel = real ? '确认并发送' : '确认并发送（合成）';
const testLabel = real ? '测试连接' : '测试连接（合成）';
const invoke = window.__TAURI__.core.invoke;
const app = new SourceConversation({
    invoke: (command, request)=>invoke(command, new TextEncoder().encode(JSON.stringify(request)))
});
const esc = (s)=>String(s ?? '').replace(/[&<>"']/g, (c)=>({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[c]);
const cloud = [
    'OpenAI',
    'Anthropic',
    'Google Gemini',
    'DeepSeek',
    'Kimi',
    'OpenRouter',
    '其他 OpenAI-compatible 服务',
    '自定义兼容接口'
];
const local = [
    'Ollama',
    'LM Studio',
    'OpenAI-compatible 本地接口',
    '自定义本地服务'
];
let page = 'Today', opened = false, busy = false, notice = '', turns = [], settings = null, preview = null, detail = null, correction = null, excluded = [];
function makeDraft() {
    const id = crypto.randomUUID();
    return {
        requestId: id,
        draftId: 'draft:' + id,
        conversationId: 'source-chat',
        turnId: id,
        revision: 1,
        text: ''
    };
}
let draft = makeDraft();
let nextCursor;
let sourceStatus = null, sourceRows = [], sourceQuery = '', localSnapshot = null;
async function sourceCall(command, payload = {}) {
    return invoke(command, {
        request: {
            version: 1,
            payload
        }
    });
}
const button = (a, text, id = '', secondary = false)=>`<button class="button ${secondary ? 'secondary' : 'primary'}" data-action="${a}" data-id="${esc(id)}" ${busy ? 'disabled' : ''}>${text}</button>`;
const messages = {
    provider_not_enabled: '请先在 Settings 保存合成凭据、测试并启用模型。',
    context_stale: '来源已变化，请重新预览。',
    preview_stale: '预览已失效，请重新预览。',
    preview_expired: '预览已过期，请重新预览。',
    database_unavailable: '本地保存暂不可用，编辑器内容仍保留。',
    confirmation_rejected: '确认不匹配，未发送。',
    credential_invalid: '请输入符合格式的合成测试凭据。',
    dispatch_outcome_unknown: '可能已发送，结果未确认；不会自动重发。',
    context_budget_rejected: '上下文超过预算，请收窄问题。',
    sensitive_content_rejected: '内容可能包含秘密，请编辑后再试。'
};
function error(e) {
    const code = e?.code || e?.message || 'operation_failed';
    return messages[code] || `当前操作未完成（${esc(code)}）。`;
}
function settingsPanel() {
    return `<header><div><p class="eyebrow">Settings · 模型与权限</p><h1>模型设置</h1><p>${real ? '凭据加密保存在本机；问题、答案和资料所在的业务库未加密。测试和发送由你明确触发。' : '合成离线演练 · 不访问 Provider 或 OS Keychain。'}</p></div></header><section class="config-card"><h2>DeepSeek</h2><p>${settings?.credentialState === 'stored' ? '已保存 · ••••' + esc(settings.maskedTail) : settings?.credentialState === 'cleanup_pending' ? '凭据操作待恢复' : settings?.credentialState === 'unavailable' ? '凭据暂不可用' : '尚未保存合成凭据'} · ${settings?.enabled ? '当前已启用' : '尚未启用'}</p><label>${real ? 'API Key' : '合成 API Key'}<input type="password" id="key" autocomplete="off" placeholder="${real ? '在 App 中输入，不要发到聊天' : '仅输入虚构演练值'}"></label>${button('save-key', '保存凭据')}${button('test', testLabel, '', true)}${button('recover', '恢复凭据操作', '', true)}${button('delete-key', '删除凭据', '', true)}<label>本次测试得到的模型<select id="model">${(settings?.models || []).map((m)=>`<option ${settings.modelId === m ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></label>${button('select', '选择模型', '', true)}${button('enable', settings?.enabled ? '停用模型' : '启用此模型')}</section><div class="source-grid"><section class="config-card"><h2>云端服务目录</h2>${cloud.map((s)=>`<p>${s}<small> · ${s === 'DeepSeek' ? real ? '本轮可用' : '本轮合成演练' : '目录保留，未连接'}</small></p>`).join('')}</section><section class="config-card"><h2>本地服务目录</h2>${local.map((s)=>`<p>${s}<small> · 不探测进程</small></p>`).join('')}</section></div>`;
}
function disclosure() {
    if (!preview) return '';
    return `<section class="config-card" aria-label="本次披露预览"><p class="eyebrow">本次披露预览</p><h2>${esc(preview.provider)} · ${esc(preview.modelId)}</h2><p>${esc(preview.authority)}</p><h3>你的问题</h3><p>${esc(preview.question)}</p><details><summary>模型说明（会一起发送）</summary><p>${esc(preview.instructions)}</p></details>${preview.items.map((i)=>`<article class="record"><div><strong>${esc(i.citationId)} · ${i.kind === 'source' ? '已导入来源' : '用户纠正'}</strong><p>${esc(i.text)}</p><small>${esc(i.source?.locator || '用户表达')} ${i.source ? '· v' + i.source.version : ''}</small></div>${i.source ? button('remove', '本次移除', i.source.segmentId, true) : ''}</article>`).join('')}<p>${preview.state === 'no_match' ? '当前已导入资料中未找到相关依据，不生成回答。' : `来源 ${preview.budget.usedSourceScalars}/2400 字符 · 请求 ${preview.budget.usedInputBytes}/24576 字节 · 输出上限1024 token；输入token仅估算。`}</p><details><summary>完整实际请求 JSON</summary><pre class="source-original">${esc(preview.bodyJson)}</pre></details>${preview.state === 'ready' ? button('send', sendLabel) : ''}${button('cancel-preview', '取消本次预览', '', true)}</section>`;
}
function conversation() {
    return `<header><div><p class="eyebrow">Global AI · 来源支撑的对话</p><h1>把问题和已有资料连起来</h1><span class="offline-mark">P3-148 · ${real ? '来源支撑的对话' : '合成离线'}</span><p>提问先保存在本地，检索后展示实际片段，由你逐次确认。</p></div></header>${turns.map((t)=>`<section class="config-card"><p class="eyebrow">你的问题</p><p>${esc(t.text)}</p>${t.answer?.text ? `<p class="eyebrow">AI 候选 · ${t.answer.validity === 'stale' ? '已失效，保留历史' : '不是用户确认事实'}</p><p>${esc(t.answer.text)}</p>${t.answer.citations.map((c)=>button('citation', c.citationId, JSON.stringify(c.source), true)).join('')}${t.answer.invalidCitationCount ? `<p>${t.answer.invalidCitationCount} 个引用无法核实。</p>` : ''}<div class="form-actions">${button('helpful', '有帮助', t.answer.answerId, true)}${button('correct', '纠正', t.answer.answerId, true)}${button('reject', '不适合', t.answer.answerId, true)}</div>` : t.answer ? `<p>${esc(t.answer.state)} · ${error({
            code: t.answer.errorCode || 'dispatch_outcome_unknown'
        })} · 不会自动重发。</p>` : '<p>问题已保存。</p>'}${button('preview', '重新预览', t.turnId, true)}</section>`).join('')}${nextCursor ? button('next-page', '查看更多对话', '', true) : ''}${disclosure()}${correction ? `<section class="config-card"><h2>纠正这条回答</h2><label>你的纠正<textarea id="correction" maxlength="2000"></textarea></label>${button('save-correction', '保存纠正')}${button('cancel-correction', '取消', '', true)}</section>` : ''}${detail ? `<section class="config-card"><h2>已导入来源依据 · v${detail.version}</h2>${detail.segments.map((s)=>`<small>${esc(s.locator)}</small><pre class="source-original">${esc(s.text)}</pre>`).join('')}</section>` : ''}`;
}
function render() {
    document.getElementById('app').innerHTML = `<div class="app-shell"><nav class="rail" aria-label="主导航"><span class="brand">✳</span>${[
        'Today',
        'Me',
        'Contexts',
        'Memory'
    ].map((p, i)=>`<button class="rail-button ${page === p ? 'is-current' : ''}" data-page="${p}" aria-label="${p}" title="${p}">${[
            '◉',
            '♙',
            '▦',
            '◇'
        ][i]}</button>`).join('')}<span class="rail-spacer"></span><button class="rail-button" data-page="Settings" aria-label="Settings">⚙</button></nav><main id="main" class="conversation-main">${!opened ? `<header><div><h1>来源支撑的 AI 对话</h1><p>${real ? '打开已有本地对话与已导入资料；不会重新扫描来源目录。请先关闭147，并在使用148期间保持147关闭。' : '合成离线演练，仅使用虚构资料。打开后恢复本地对话；启动不访问 OS 凭据、网络或来源目录。'}</p>${button('open', '打开已有本地会话')}</div></header>` : page === 'Settings' ? settingsPanel() + sourcePanel() : page === 'Memory' ? sourceMemory() : page === 'Me' ? personalMemory() : page === 'Contexts' ? sourcePanel() : conversation()}<p id="notice" class="notice" role="status">${notice}</p></main>${opened && page !== 'Settings' && !preview && !correction ? `<section class="composer" aria-label="Global AI"><strong>✳ Global AI</strong><label class="sr-only" for="conversation">自然提问</label><textarea id="conversation" maxlength="2000" placeholder="例如：纸鹤项目的图纸应该如何整理？">${esc(draft.text)}</textarea><div class="composer-footer"><small>先保存，再检索与预览；不会自动发送。</small>${button('ask', '提问')}</div></section>` : ''}</div>`;
}
async function refresh() {
    const data = await app.read('source-chat');
    turns = data.turns;
    nextCursor = data.nextCursor;
    settings = await app.settings();
    sourceStatus = (await sourceCall('get_source_status')).connectors[0] || null;
    localSnapshot = await invoke('get_today', {
        request: {
            version: 2,
            operation: 'snapshot',
            payload: {}
        }
    });
}
async function act(a, id) {
    if (busy) return;
    let questionStored = false;
    const key = document.getElementById('key')?.value;
    const model = document.getElementById('model')?.value;
    const correctionText = document.getElementById('correction')?.value;
    busy = true;
    notice = '';
    render();
    try {
        if (a === 'next-page') {
            const data = await app.read('source-chat', nextCursor);
            turns.push(...data.turns);
            nextCursor = data.nextCursor;
        } else if (a === 'source-search') {
            if (sourceStatus) {
                sourceQuery = sourceQuery.trim();
                sourceRows = (await sourceCall('get_source_evidence', {
                    mode: 'search',
                    connectorId: sourceStatus.connectorId,
                    query: sourceQuery,
                    expectedGeneration: sourceStatus.grantGeneration
                })).results;
            }
        } else if (a === 'source-detail') {
            detail = await sourceCall('get_source_evidence', {
                mode: 'detail',
                connectorId: sourceStatus.connectorId,
                sourceRef: id,
                expectedVersion: sourceRows.find((r)=>r.sourceRef === id)?.version || sourceStatus.files.find((f)=>f.sourceRef === id).version
            });
        } else if (a === 'source-disconnect') {
            await sourceCall('control_source_job', {
                requestId: crypto.randomUUID(),
                connectorId: sourceStatus.connectorId,
                expectedGeneration: sourceStatus.grantGeneration,
                action: 'disconnect'
            });
            sourceRows = [];
            preview = null;
            detail = null;
            await refresh();
        } else if (a === 'open') {
            if (real && !confirm('请确认已关闭147，并在使用148期间不重开147。打开已有本地会话不会重新扫描来源。')) return;
            const recovered = await app.open('source-chat');
            if (recovered.pendingDraft) draft = recovered.pendingDraft;
            opened = true;
            await refresh();
        } else if (a === 'ask') {
            clearTimeout(autosave);
            await draftQueue;
            await app.ask(draft);
            questionStored = true;
            const turn = draft.turnId;
            draft = makeDraft();
            await refresh();
            excluded = [];
            preview = await app.preview(turn);
        } else if (a === 'preview') {
            excluded = [];
            preview = await app.preview(id);
        } else if (a === 'remove') {
            excluded.push(id);
            preview = await app.preview(turns.find((t)=>t.questionId === preview.questionId).turnId, excluded);
        } else if (a === 'send') {
            notice = real ? '发送中，请等待；不会自动重发。' : '发送中（合成），请等待；不会自动重发。';
            render();
            const result = await app.send(preview);
            notice = result.state === 'succeeded' ? '回答已保存。' : error({
                code: result.errorCode
            });
            preview = null;
            await refresh();
        } else if (a === 'cancel-preview') {
            await app.cancel(preview);
            preview = null;
        } else if (a === 'citation') {
            const s = JSON.parse(id);
            detail = await invoke('get_source_evidence', {
                request: {
                    version: 1,
                    payload: {
                        mode: 'detail',
                        connectorId: s.connectorId,
                        sourceRef: s.sourceRef,
                        expectedVersion: s.version
                    }
                }
            });
        } else if (a === 'correct') {
            correction = turns.find((t)=>t.answer?.answerId === id)?.answer;
        } else if (a === 'cancel-correction') {
            correction = null;
        } else if ([
            'save-correction',
            'helpful',
            'reject'
        ].includes(a)) {
            const target = a === 'save-correction' ? correction : turns.find((t)=>t.answer?.answerId === id)?.answer;
            const p = {
                requestId: crypto.randomUUID(),
                answerId: target.answerId,
                expectedAnswerRevision: target.revision,
                decision: a === 'save-correction' ? 'correct' : a
            };
            if (a === 'save-correction') {
                p.correctionText = correctionText;
                p.affectedCitationIds = [];
            }
            await app.call('decide_understanding_feedback', 'answer_feedback', p);
            correction = null;
            preview = null;
            await refresh();
            notice = '反馈已保存。';
        } else {
            const p = {
                requestId: crypto.randomUUID(),
                profileId: 'deepseek-default'
            };
            if (a === 'save-key') {
                Object.assign(p, {
                    expectedCredentialRevision: settings.credentialRevision,
                    apiKey: key
                });
                await app.call('save_ai_provider_credential', 'replace_credential', p);
            } else if (a === 'test') {
                Object.assign(p, {
                    expectedCredentialRevision: settings.credentialRevision,
                    confirmation: 'test_deepseek_models_once'
                });
                const tested = await app.call('test_ai_provider_connection', 'test_connection', p);
                if (tested.state !== 'succeeded') throw {
                    code: tested.errorCode
                };
            } else if (a === 'recover') {
                Object.assign(p, {
                    expectedCredentialRevision: settings.credentialRevision,
                    confirmation: 'recover_owned_credential_operations'
                });
                await app.call('save_ai_provider_credential', 'recover_credentials', p);
            } else if (a === 'delete-key') {
                if (!confirm(real ? '删除此凭据并停用发送？' : '删除本任务合成凭据？')) return;
                Object.assign(p, {
                    expectedCredentialRevision: settings.credentialRevision,
                    confirmation: 'delete_this_credential'
                });
                await app.call('save_ai_provider_credential', 'delete_credential', p);
            } else if (a === 'select') {
                Object.assign(p, {
                    expectedProfileRevision: settings.profileRevision,
                    testReceiptId: settings.testReceiptId,
                    modelId: model
                });
                await app.call('save_ai_provider_settings', 'select_model', p);
            } else if (a === 'enable') {
                Object.assign(p, {
                    expectedProfileRevision: settings.profileRevision,
                    enabled: !settings.enabled
                });
                await app.call('set_ai_provider_enabled', 'set_enabled', p);
            }
            await refresh();
            notice = settings?.credentialState === 'cleanup_pending' ? '凭据操作尚未完成，请明确恢复；不会后台清理。' : '设置已保存。';
            preview = null;
        }
    } catch (e) {
        notice = questionStored || a === 'preview' || a === 'remove' ? `问题已保存，本次预览暂未完成（${esc(e?.code || 'operation_failed')}），可重新预览。` : error(e);
    } finally{
        busy = false;
        render();
        if (preview) document.querySelector('[aria-label="本次披露预览"]')?.scrollIntoView({
            block: 'start'
        });
    }
}
let autosave;
let draftQueue = Promise.resolve();
document.addEventListener('input', (e)=>{
    if (e.target.id === 'source-query') sourceQuery = e.target.value;
    if (e.target.id === 'conversation') {
        draft.text = e.target.value;
        draft.revision++;
        draft.requestId = crypto.randomUUID();
        clearTimeout(autosave);
        const captured = {
            ...draft
        };
        autosave = setTimeout(()=>{
            draftQueue = draftQueue.then(()=>app.call('capture_record', 'draft_question', captured)).then(()=>undefined).catch((e)=>{
                notice = error(e);
                const n = document.getElementById('notice');
                if (n) n.textContent = notice;
            });
        }, 250);
    }
});
document.addEventListener('click', (e)=>{
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.page) {
        page = b.dataset.page;
        render();
        window.scrollTo(0, 0);
    } else if (b.dataset.action) void act(b.dataset.action, b.dataset.id || '');
});
render();
function sourcePanel() {
    return `<section class="config-card"><p class="eyebrow">数据与隐私</p><h2>来源</h2><p>仅使用已导入资料；本地检索不会发送到云端。</p><p>${sourceStatus ? esc(sourceStatus.status) + ' · 正文已解析 ' + sourceStatus.parsed : '尚无已导入来源'}</p><button class="button secondary" disabled>重新扫描（本次会话未启用）</button>${sourceStatus?.status === 'active' ? button('source-disconnect', '断开来源', '', true) : ''}<p>断开保留历史，旧预览失效。不会获取目录外文件、网页或未解析附件。</p></section>`;
}
function sourceMemory() {
    return `<header><div><p class="eyebrow">Memory · 来源与引用</p><h1>找回原文依据</h1><p>检索结果是已导入原文，不等于AI理解或用户确认事实。</p></div></header><section class="config-card"><label>本地检索<input id="source-query" value="${esc(sourceQuery)}" placeholder="例如：纸鹤项目"></label>${button('source-search', '检索来源')}${sourceRows.map((r)=>`<article class="record"><div><p>${esc(r.text)}</p><small>原始来源 · v${r.version} · ${esc(r.locator)}</small></div>${button('source-detail', '查看原文依据', r.sourceRef, true)}</article>`).join('') || '<p>当前没有检索结果。</p>'}</section>${detail ? `<section class="config-card"><h2>${esc(detail.title || '已导入来源')} · v${detail.version}</h2>${detail.segments.map((s)=>`<small>${esc(s.locator)}</small><pre class="source-original">${esc(s.text)}</pre>`).join('')}</section>` : ''}${personalMemory()}`;
}
function personalMemory() {
    return `<section class="config-card"><h2>已确认长期信息</h2>${(localSnapshot?.memories || []).filter((m)=>m.status === 'active').map((m)=>`<p>${esc(m.statement)} · 用户明确确认</p>`).join('') || '<p>还没有已确认长期信息。</p>'}<h2>当前状态</h2>${(localSnapshot?.states || []).filter((s)=>s.status === 'active').map((s)=>`<p>${esc(s.stateKey)} · ${esc(s.value)}</p>`).join('') || '<p>没有当前有效状态。</p>'}<p>问题、模型回答和纠正不会自动写成长期事实。</p></section>`;
}
